export { default as HomePage } from './HomePage';
export { default as MyProfilePage } from './MyProfilePage';