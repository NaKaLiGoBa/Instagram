import React from "react";
import { Typography } from "@mui/material";
import styled from "styled-components";

const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
`;

const ProfileWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
`;

const ProfileImage = styled.img`
  width: 150px;
  height: 150px;
  border-radius: 50%;
  margin-right: 50px;
`;

const MyProfile = () => {
  const userProfile = {
    username: "zero_Young",
    fullName: "jinyoung",
    bio: "Hello, I am a user of Instagram!",
    postsCount: 15,
    followersCount: 100,
    followingCount: 50,
    profileImageURL: "/images/profile.jpg",
  };

  const MainLayout = styled.div`
    padding: 30px 20px 0px;
  `;

  const StyledTypography = styled(Typography)`
    margin-bottom: 30px; // 원하는 마진 값으로 설정
  `;

  const ProfileInfo = ({ userProfile }) => (
    <div style={{ textAlign: "left", fontSize: "15px" }}>
      <StyledTypography variant="h5" gutterBottom>
        {userProfile.username}
      </StyledTypography>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          width: "300px",
        }}
      >
        <Typography variant="body1" gutterBottom>
          Posts {userProfile.postsCount}
        </Typography>
        <Typography variant="body1" gutterBottom>
          Followers {userProfile.followersCount}
        </Typography>
        <Typography variant="body1" gutterBottom>
          Following {userProfile.followingCount}
        </Typography>
      </div>
      <Typography variant="body1" color="textSecondary" gutterBottom>
        {userProfile.fullName}
      </Typography>
      <Typography variant="body1" gutterBottom>
        {userProfile.bio}
      </Typography>
    </div>
  );

  return (
    <MainLayout>
      <Container>
        <ProfileWrapper>
          <ProfileImage src={userProfile.profileImageURL} alt="User Profile" />
          <ProfileInfo userProfile={userProfile} />
        </ProfileWrapper>
      </Container>
    </MainLayout>
  );
};

export default MyProfile;
