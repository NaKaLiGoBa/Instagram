export { default as HomeRoute } from './HomeRoute';
export { default as AuthRoute } from './AuthRoute';